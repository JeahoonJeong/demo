package com.students;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class StudentsMain {

	public static void main(String[] args) {
	
		
		Scanner sc = new Scanner(System.in);
		StudentImpl st = new StudentImpl();

		while(true){
			System.out.print("1.�Է� 2.��� 3.���� =>");
			String ch = sc.next();
			
			
			switch (ch) {
			case "1":
				st.input();
				break;
			case "2":
				st.print();
				break;
			case "3":
				st.exit();
				return;
			default:
				break;
			}
			
		}
		
	}

}
