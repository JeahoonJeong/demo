package com.students;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class StudentImpl implements Students{
	
	ArrayList<StudentsVO> list = new ArrayList<StudentsVO>();
	
	
	public StudentImpl(){
		
		try {
			
			FileInputStream fis = new FileInputStream("d:\\doc\\hw.txt");
			ObjectInputStream ois = new ObjectInputStream(fis);
			
			ArrayList<StudentsVO> temp = (ArrayList<StudentsVO>)ois.readObject();
			
			Iterator<StudentsVO> it = temp.iterator();
			
			while(it.hasNext()){
				StudentsVO ob = it.next();
				list.add(ob);
			}
			
			fis.close();
			ois.close();
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
	}
	
	
	@Override
	public void input() {
		
		StudentsVO ob = new StudentsVO();
		Scanner sc = new Scanner(System.in);
		
		System.out.print("�̸�?");
		ob.setName(sc.next());
		
		System.out.print("����?");
		ob.setBirth(sc.next());
		
		System.out.print("����?");
		ob.setScore(sc.next());
		
		list.add(ob);
		
	}

	@Override
	public void print() {
		
		for(int i =0;i<list.size();i++){
			System.out.println(list.get(i));
		}
		System.out.println();
		
	}

	@Override
	public void exit() {
		
		try {
			FileOutputStream fos = new FileOutputStream("d:\\doc\\hw.txt");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			
			oos.writeObject(list);
			
			fos.close();
			oos.close();
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
	}

}


































