package com.students;

public interface Students {
	
	public void input();
	public void print();
	public void exit();

}
