package com.day3;

public class Test7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("��Ŭ����!");
		
		System.out.println("����");
	}

}
